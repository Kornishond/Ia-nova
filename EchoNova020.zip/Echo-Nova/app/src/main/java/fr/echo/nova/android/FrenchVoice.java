package fr.echo.nova.android;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import java.util.Comparator;
import java.util.Locale;
import java.util.Set;

/** French offline TextToSpeech only. No automatic English or network voice fallback. */
public final class FrenchVoice {
    public interface ReadyListener { void onStatusChanged(String status); }
    public interface FinishedListener { void onFinished(boolean spoken, String explanation); }

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ReadyListener readyListener;
    private TextToSpeech engine;
    private boolean ready = false;
    private String status = "Initialisation de la voix française…";
    private long utteranceId = 0;
    private FinishedListener finished;

    public FrenchVoice(Context context, ReadyListener listener) {
        this.readyListener = listener;
        // Callback may be delivered before constructor assignment: defer setup via Handler.
        engine = new TextToSpeech(context.getApplicationContext(), result -> main.post(() -> configure(result)));
    }

    private void configure(int initStatus) {
        if (engine == null) return;
        if (initStatus != TextToSpeech.SUCCESS) {
            setStatus("Moteur vocal Android indisponible.");
            return;
        }
        try {
            int language = engine.setLanguage(Locale.FRANCE);
            if (language == TextToSpeech.LANG_NOT_SUPPORTED || language == TextToSpeech.LANG_MISSING_DATA) {
                setStatus("Aucune voix française installée. Installe les données vocales françaises Android.");
                return;
            }
            Set<Voice> candidates = engine.getVoices();
            Voice selected = null;
            if (candidates != null) {
                selected = candidates.stream()
                    .filter(voice -> "fr".equalsIgnoreCase(voice.getLocale().getLanguage()) && !voice.isNetworkConnectionRequired())
                    .max(Comparator.comparingInt(voice ->
                        voice.getQuality() * 10 + ("FR".equalsIgnoreCase(voice.getLocale().getCountry()) ? 5 : 0)))
                    .orElse(null);
            }
            if (selected == null) {
                setStatus("Aucune voix française explicitement hors ligne trouvée. Le texte reste disponible.");
                return;
            }
            int chosen = engine.setVoice(selected);
            if (chosen != TextToSpeech.SUCCESS) {
                setStatus("Impossible de sélectionner la voix française hors ligne.");
                return;
            }
            engine.setSpeechRate(0.97f);
            engine.setPitch(1.03f);
            engine.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utterance) { }
                @Override public void onDone(String utterance) { main.post(() -> finishFor(utterance, true, "")); }
                @Override public void onError(String utterance) { main.post(() -> finishFor(utterance, false, "Échec du moteur vocal.")); }
                @Override public void onError(String utterance, int errorCode) {
                    main.post(() -> finishFor(utterance, false, "Erreur TTS " + errorCode));
                }
            });
            ready = true;
            setStatus("Voix française hors ligne : " + selected.getName());
        } catch (RuntimeException ex) {
            ready = false;
            setStatus("Erreur vocale : " + ex.getClass().getSimpleName());
        }
    }

    private void setStatus(String text) { status = text; readyListener.onStatusChanged(text); }
    public String status() { return status; }
    public boolean available() { return ready; }

    public boolean speak(String text, FinishedListener listener) {
        if (!ready || engine == null || text == null || text.trim().isEmpty()) return false;
        stop();
        this.finished = listener;
        String id = String.valueOf(++utteranceId);
        int result = engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, id);
        if (result != TextToSpeech.SUCCESS) {
            finished = null;
            return false;
        }
        return true;
    }

    private void finishFor(String id, boolean ok, String note) {
        if (!id.equals(String.valueOf(utteranceId))) return;
        FinishedListener cb = finished;
        finished = null;
        if (cb != null) cb.onFinished(ok, note);
    }

    public void stop() {
        ++utteranceId; // invalidate callbacks from previous utterance
        finished = null;
        if (engine != null) try { engine.stop(); } catch (RuntimeException ignored) { }
    }

    public void shutdown() {
        stop();
        if (engine != null) { engine.shutdown(); engine = null; }
        ready = false;
    }
}
