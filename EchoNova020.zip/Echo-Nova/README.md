# Écho Nova 0.2.0 — Prototype appels entrants

**Attention :** `fr.echo.nova.beta` est un identifiant volontairement distinct de `fr.echo.nova` car les APK GitHub Actions debug sont signés avec une clé éphémère. La nouvelle version peut donc coexister avec 0.1.0 et Écho Work sans désinstallation ni perte de données.

## Améliorations

- `Tester appel entrant` : une notification locale de type appel, avec écran d'acceptation/refus, peut apparaître même lorsque l'application est en arrière-plan. Les notifications et intentions plein écran restent sujettes aux autorisations Android.
- `Auto ON` : consentement explicite pour recevoir au plus une invitation programmée par jour, seulement entre 10 h et 21 h. Planification approximative, pouvant être retardée par Android ; désactivée par défaut. Réarmement après redémarrage.
- Une conversation mains libres débute **uniquement après acceptation** ; aucune écoute permanente en arrière-plan.
- Protection anti-boucle : les transcriptions ressemblant très fortement à la dernière phrase prononcée par Écho sont ignorées pour limiter l'écho acoustique. Les autres questions restent acceptées.

## Limites restant à corriger

- **Pas de LLM embarqué** : les réponses restent fondées sur des règles. Ne pas appeler cette version une IA conversationnelle naturelle.
- **Voix Android classique** : la nouvelle voix générative ML Kit est à intégrer et à tester séparément sur Pixel 8 ; le simple réglage des paramètres TTS ne rendrait pas cette voix humaine.
- Reconnaissance hors ligne Android encore approximative ; le mode GenAI *advanced* ML Kit n'est pas disponible sur Pixel 8 selon la documentation du 12/11/2026. L'intégration d'un véritable ASR local sera nécessaire.
- La notification n'est **pas** un véritable appel sur le réseau téléphonique ; son affichage plein écran n'est pas garanti (Android 14+).
- Compilation Android de cette version et tests réels sur Pixel 8 : **à faire**.

## Construction

Sur GitHub Actions : extraire le ZIP puis `chmod +x Echo-Nova/gradlew Echo-Nova/scripts/*.sh` et `cd Echo-Nova && ./scripts/build_android.sh`. Le `build.yml` inclus peut être importé comme `.github/workflows/build.yml`, mais ce dépôt utilise actuellement un ZIP en racine.
