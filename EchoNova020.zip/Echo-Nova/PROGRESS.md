# 0.2.0 beta : validation partielle

## Réalisé
- Nouvelle variante `fr.echo.nova.beta` pour ne pas forcer la désinstallation de 0.1.0 (signatures debug GH variables).
- Invitations d'appels entrantes via notifications, affichage verrouillé sous réserve d'autorisations Android, acceptation et refus.
- Activation volontaire des occasions d'appels (OFF par défaut) et replanification au redémarrage.
- Protection contre l'écho de la dernière réponse vocale et doublons de transcription.
- Refus suivi d'une période sans invitation d'au moins 48 heures.
- Tests Java purs : 45 assertions et 12 fichiers Java analysés syntaxiquement.

## Non vérifié / non implémenté
- Aucune compilation Android de 0.2.0 exécutée dans l'environnement local (SDK absent).
- Aucun test sur Pixel 8 pour les notifications sur écran verrouillé et le mode conversation.
- Voix Android TTS inchangée ; ML Kit GenAI TTS et ses modèles n'ont pas encore été intégrés.
- Reconnaissance locale Android toujours approximative : modèle ASR spécialisé non intégré.
- Moteur de dialogue : règles, aucun véritable LLM.
- Pas de véritable appel sur réseau téléphonique ni conversation audio en arrière-plan lorsque l'écran est verrouillé.

## Prochaines étapes
1. Compiler via GitHub Actions, corriger éventuelles erreurs.
2. Vérifier invitation, refus, réponse et autorisations sur Pixel 8.
3. Intégrer la synthèse locale ML Kit GenAI TTS fr-FR (voix star16 / star08) après validation du téléchargement.
4. Évaluer ASR français dédié et modèle de dialogue quantifié local avant de promettre une conversation naturelle.
