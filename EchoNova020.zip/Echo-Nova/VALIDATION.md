# Rapport de validation — Écho Nova 0.1.0

Date : 2026-11-12

## Validé sur cette machine

- Code métier original (5 classes Java core) et tests Java purs : **39 assertions réussies**.
- Analyse syntaxique des **9 classes Java Android + core** par le parseur JDK (sans résolution des APIs Android) : réussie.
- Structure XML/manifest et Android ID `fr.echo.nova` : valide.
- Manifest sans permission INTERNET et seulement RECORD_AUDIO : vérifié.
- Compatibilité Android 12+ : retrait de `String.isBlank()` (disponible seulement API 33).
- Stratégie hors ligne : utilisation de `SpeechRecognizer.createOnDeviceSpeechRecognizer`, filtrage voix `isNetworkConnectionRequired() == false` : vérifiée dans le code.
- Certificat de signature Nova privé distinct créé : oui. Empreinte publique SHA256 dans `CERTIFICAT_PUBLIC.txt`.

## Pas validé

- Compilation réelle avec Android SDK : **NON**.
- APK généré : **NON**.
- Installation sur Google Pixel 8 : **NON**.
- Transcription française / qualité de voix / dialogue temps réel : **NON**.
- Intégration d'un véritable LLM : **NON** (moteur initial à règles seulement).

## Blocage de compilation constaté

La commande `./gradlew --offline --no-daemon :app:assembleDebug` échoue avant la compilation du projet, car la distribution Gradle 8.13 n'est pas présente et le domaine `services.gradle.org` n'est pas résolu depuis cet environnement. Le SDK Android 35 est également absent. Voir `COMPILATION_ATTEMPT.log`.

Il ne serait pas honnête de qualifier cette version de « stable », ni de prétendre livrer un APK.

## Pour terminer un premier APK

Sur une machine disposant d'un SDK Android et de Gradle :

1. Compiler `./gradlew :app:assembleDebug`.
2. Corriger d'éventuelles erreurs de compilation Android (aucune résolution de symboles Android possible ici).
3. Installer sur Pixel 8 sous l'identifiant `fr.echo.nova`.
4. Tester texte → réponse et mémoire, reconnaissance française réelle, voix locale puis mode appel au premier plan.
5. Ne pas désinstaller ni remplacer Écho 4.0.0 de Work.

Le système de signature fournit un keystore release privé dans une archive distincte. Le certificat de débogage n'est **pas** le certificat release et changer de signature sur le même ID nécessite de désinstaller la build précédente (ou une migration explicite des données).
