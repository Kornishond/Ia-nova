plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "fr.echo.nova"
    compileSdk = 35

    defaultConfig {
        applicationId = "fr.echo.nova.star16"
        minSdk = 31
        targetSdk = 35
        versionCode = 3
        versionName = "0.3.0-star16"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // A signature-specific APK is generated only when the explicit
    // Echo Nova signing environment variables are provided.
    signingConfigs {
        create("novaRelease") {
            val signingPath = System.getenv("ECHO_NOVA_KEYSTORE")
            if (!signingPath.isNullOrBlank()) {
                storeFile = file(signingPath)
                storePassword = System.getenv("ECHO_NOVA_STORE_PASSWORD")
                keyAlias = System.getenv("ECHO_NOVA_KEY_ALIAS") ?: "echo_nova"
                keyPassword = System.getenv("ECHO_NOVA_KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            val signingPath = System.getenv("ECHO_NOVA_KEYSTORE")
            if (!signingPath.isNullOrBlank()) {
                signingConfig = signingConfigs.getByName("novaRelease")
            }
        }
    }
}


dependencies {
    implementation("com.google.mlkit:genai-text-to-speech:1.0.0-alpha1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
}
