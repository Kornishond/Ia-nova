package fr.echo.nova.core;

import java.text.Normalizer;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Rejects clear acoustic feedback, not low-confidence or merely similar questions. */
public final class EchoLoopGuard {
    private String lastSpoken = "";
    private String lastHeard = "";
    private long heardAt = 0;

    public synchronized void spoke(String reply) {
        lastSpoken = normalized(reply);
    }

    public synchronized boolean accept(String heard, long timestampMs) {
        String current = normalized(heard);
        if (current.length() < 2) return false;
        if (current.length() >= 16 && current.equals(lastSpoken)) return false;
        if (current.length() >= 24 && lastSpoken.length() >= 24
                && overlap(current, lastSpoken) >= 0.84) return false;
        if (timestampMs - heardAt < 9000 && timestampMs >= heardAt
                && current.equals(lastHeard)) return false;
        lastHeard = current;
        heardAt = timestampMs;
        return true;
    }

    private static double overlap(String a, String b) {
        Set<String> aWords = new HashSet<>(Arrays.asList(a.split(" ")));
        Set<String> bWords = new HashSet<>(Arrays.asList(b.split(" ")));
        if (aWords.size() < 5 || bWords.size() < 5) return 0;
        int common = 0;
        for (String word : aWords) if (bWords.contains(word)) common++;
        return (double) common / Math.min(aWords.size(), bWords.size());
    }

    private static String normalized(String text) {
        if (text == null) return "";
        return Normalizer.normalize(text.toLowerCase(Locale.FRANCE), Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .replaceAll("[^a-z0-9 ]", " ")
                .replaceAll("\\s+", " ").trim();
    }
}
