package fr.echo.nova.core;

import java.util.List;

/** Small capability boundary: no Android dependency in the conversation engine. */
public interface MemoryStore {
    void remember(String information);
    List<String> recallRecent(int limit);
    void forgetAll();
}
