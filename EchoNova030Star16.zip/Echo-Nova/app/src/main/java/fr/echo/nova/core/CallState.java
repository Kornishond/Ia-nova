package fr.echo.nova.core;

/** Minimal pure-Java state machine for on-screen calls, never real phone calls. */
public final class CallState {
    public enum Phase { IDLE, LISTENING, THINKING, SPEAKING }
    private Phase phase = Phase.IDLE;
    private boolean inCall = false;

    public synchronized void startCall() { inCall = true; phase = Phase.IDLE; }
    public synchronized void endCall() { inCall = false; phase = Phase.IDLE; }
    public synchronized boolean isInCall() { return inCall; }
    public synchronized Phase phase() { return phase; }
    public synchronized void onListening() { if (inCall) phase = Phase.LISTENING; }
    public synchronized void onThinking() { if (inCall) phase = Phase.THINKING; }
    public synchronized void onSpeaking() { if (inCall) phase = Phase.SPEAKING; }
    public synchronized void onTurnFinished() { if (inCall) phase = Phase.IDLE; }
}
