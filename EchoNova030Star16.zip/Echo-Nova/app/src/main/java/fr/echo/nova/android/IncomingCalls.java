package fr.echo.nova.android;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.SystemClock;

import java.util.Calendar;
import java.util.concurrent.TimeUnit;

/** Opt-in call invitations: no background microphone or phone-network usage. */
public final class IncomingCalls {
    static final String ACTION_TRIGGER = "fr.echo.nova.action.SCHEDULED_CALL";
    static final String ACTION_DECLINE = "fr.echo.nova.action.DECLINE_CALL";
    static final String ACTION_ACCEPT = "fr.echo.nova.action.ACCEPT_CALL";
    private static final String CHANNEL = "echo_nova_incoming_v2";
    private static final int ID = 508;
    private static final int ALARM_REQUEST = 509;
    private static final String PREFS = "incoming_calls";
    private static final String ENABLED = "enabled";
    private static final String NEXT = "next_approx_ms";
    private static final String DECLINED = "last_declined_ms";
    private IncomingCalls() { }

    public static boolean enabled(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(ENABLED, false);
    }

    public static void setEnabled(Context c, boolean enabled) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(ENABLED, enabled).apply();
        if (enabled) scheduleNext(c);
        else { cancel(c); dismiss(c); }
    }

    /** Approximate timing, Android may delay delivery in Doze or under background restrictions. */
    public static void scheduleNext(Context context) {
        Context c = context.getApplicationContext();
        if (!enabled(c)) return;
        Calendar when = Calendar.getInstance();
        // 22..29 hours after the previous opportunity, deterministic jitter by date.
        int extraHours = Math.floorMod(when.get(Calendar.DAY_OF_YEAR) * 37 + 11, 8);
        long declinedAt = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(DECLINED, 0);
        when.add(Calendar.HOUR_OF_DAY, 22 + extraHours);
        if (declinedAt > 0 && System.currentTimeMillis() - declinedAt < TimeUnit.DAYS.toMillis(2)) {
            long cooldown = declinedAt + TimeUnit.DAYS.toMillis(2);
            if (when.getTimeInMillis() < cooldown) when.setTimeInMillis(cooldown);
        }
        // Calls only in user's local hours 10:00..20:59.
        if (when.get(Calendar.HOUR_OF_DAY) < 10) when.set(Calendar.HOUR_OF_DAY, 10 + extraHours % 4);
        if (when.get(Calendar.HOUR_OF_DAY) >= 21) {
            when.add(Calendar.DAY_OF_YEAR, 1);
            when.set(Calendar.HOUR_OF_DAY, 10 + extraHours % 4);
        }
        long delay = Math.max(TimeUnit.MINUTES.toMillis(30), when.getTimeInMillis() - System.currentTimeMillis());
        Intent intent = new Intent(c, CallAlarmReceiver.class).setAction(ACTION_TRIGGER);
        PendingIntent pi = PendingIntent.getBroadcast(c, ALARM_REQUEST, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager alarms = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (alarms == null) return;
        alarms.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + delay, pi);
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong(NEXT, when.getTimeInMillis()).apply();
    }

    public static String nextText(Context c) {
        long ts = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(NEXT, 0);
        if (!enabled(c)) return "désactivés";
        return ts == 0 ? "en cours de programmation" :
                "prochaine opportunité vers " + android.text.format.DateFormat.format("dd/MM à HH:mm", ts) + " (approximatif)";
    }

    private static void cancel(Context c) {
        Intent i = new Intent(c, CallAlarmReceiver.class).setAction(ACTION_TRIGGER);
        PendingIntent pi = PendingIntent.getBroadcast(c, ALARM_REQUEST, i,
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager a = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (a != null && pi != null) a.cancel(pi);
        if (pi != null) pi.cancel();
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(NEXT).apply();
    }

    static boolean notificationsAllowed(Context c) {
        return Build.VERSION.SDK_INT < 33 || c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    public static boolean showIncoming(Context context) {
        Context c = context.getApplicationContext();
        if (!notificationsAllowed(c)) return false;
        NotificationManager manager = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return false;
        Uri ringtone = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        NotificationChannel channel = new NotificationChannel(CHANNEL, "Appels entrants Écho Nova", NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("Invitations vocales activées volontairement par l'utilisateur");
        channel.setSound(ringtone, new android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION_RINGTONE).build());
        manager.createNotificationChannel(channel);
        Intent incoming = new Intent(c, IncomingCallActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent open = PendingIntent.getActivity(c, 510, incoming,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent accept = new Intent(c, MainActivity.class).setAction(ACTION_ACCEPT)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent answer = PendingIntent.getActivity(c, 511, accept,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent decline = new Intent(c, CallAlarmReceiver.class).setAction(ACTION_DECLINE);
        PendingIntent reject = PendingIntent.getBroadcast(c, 512, decline,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(fr.echo.nova.R.drawable.ic_echo_nova)
                .setContentTitle("Écho Nova t'appelle")
                .setContentText("Accepter une conversation vocale locale ?")
                .setCategory(Notification.CATEGORY_CALL)
                .setPriority(Notification.PRIORITY_HIGH)
                .setOngoing(false)
                .setAutoCancel(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(null, "Refuser", reject).build())
                .addAction(new Notification.Action.Builder(null, "Répondre", answer).build());
        if (Build.VERSION.SDK_INT < 34 || manager.canUseFullScreenIntent()) {
            builder.setFullScreenIntent(open, true);
        }
        try { manager.notify(ID, builder.build()); return true; }
        catch (SecurityException e) { return false; }
    }

    /** Refusal never implies rejection of the relationship; it only creates a quiet period. */
    public static void declined(Context context) {
        Context c = context.getApplicationContext();
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putLong(DECLINED, System.currentTimeMillis()).apply();
        dismiss(c);
        if (enabled(c)) scheduleNext(c);
    }

    public static void dismiss(Context context) {
        NotificationManager m = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (m != null) m.cancel(ID);
    }

    public static final class CallAlarmReceiver extends BroadcastReceiver {
        @Override public void onReceive(Context c, Intent intent) {
            if (intent == null) return;
            if (ACTION_DECLINE.equals(intent.getAction())) { declined(c); return; }
            if (!ACTION_TRIGGER.equals(intent.getAction()) || !enabled(c)) return;
            Calendar now = Calendar.getInstance();
            int hour = now.get(Calendar.HOUR_OF_DAY);
            if (hour >= 10 && hour < 21) showIncoming(c);
            scheduleNext(c);
        }
    }

    public static final class BootReceiver extends BroadcastReceiver {
        @Override public void onReceive(Context c, Intent intent) {
            if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()) && enabled(c)) scheduleNext(c);
        }
    }
}
