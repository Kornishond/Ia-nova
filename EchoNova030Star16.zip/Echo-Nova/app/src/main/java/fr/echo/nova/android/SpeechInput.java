package fr.echo.nova.android;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import java.util.ArrayList;

/** Microphone is used only while the activity is visible; recognizes on-device only. */
public final class SpeechInput {
    public interface Listener {
        void onState(String status);
        void onPartial(String partial);
        void onFinal(String finalText);
        void onFailure(String reason);
    }

    private final Context context;
    private final Handler main = new Handler(Looper.getMainLooper());
    private SpeechRecognizer recognizer;
    private Listener listener;
    private boolean active = false;
    private String partial = "";
    private long generation = 0;
    private Runnable pendingFallback;

    public SpeechInput(Context context) { this.context = context; }

    public boolean available() {
        try { return SpeechRecognizer.isOnDeviceRecognitionAvailable(context); }
        catch (RuntimeException ex) { return false; }
    }

    public boolean isListening() { return active; }

    public void start(Listener listener) {
        cancel();
        this.listener = listener;
        if (!available()) {
            listener.onFailure("Reconnaissance vocale hors ligne indisponible. Utilise le texte ou installe le français hors ligne dans Android.");
            return;
        }
        active = true;
        partial = "";
        long session = ++generation;
        try {
            recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(context);
            recognizer.setRecognitionListener(new Session(session));
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR");
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fr-FR");
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
            intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1300L);
            intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 800L);
            recognizer.startListening(intent);
            listener.onState("Microphone : préparation…");
        } catch (RuntimeException ex) {
            finishWithError("Impossible d'activer le microphone local : " + ex.getClass().getSimpleName());
        }
    }

    /** Stops immediately; a plausible partial transcription is not discarded. */
    public void stopAndAcceptPartial() {
        if (!active) return;
        if (!partial.trim().isEmpty()) finishWithText(partial);
        else {
            cleanup();
            if (listener != null) listener.onState("Écoute arrêtée. Aucune parole reconnue.");
        }
    }

    public void cancel() { cleanup(); listener = null; }

    private void scheduleFallback(long delayMs, long session) {
        if (pendingFallback != null) main.removeCallbacks(pendingFallback);
        pendingFallback = () -> {
            if (active && session == generation && !partial.trim().isEmpty()) finishWithText(partial);
        };
        main.postDelayed(pendingFallback, delayMs);
    }

    private void finishWithText(String text) {
        if (!active) return;
        String clean = text == null ? "" : text.trim();
        Listener callback = listener;
        cleanup();
        if (callback != null) {
            if (clean.trim().isEmpty()) callback.onFailure("Aucune transcription reçue.");
            else callback.onFinal(clean);
        }
    }

    private void finishWithError(String message) {
        if (!active) return;
        Listener callback = listener;
        cleanup();
        if (callback != null) callback.onFailure(message);
    }

    private void cleanup() {
        active = false;
        ++generation;
        if (pendingFallback != null) {
            main.removeCallbacks(pendingFallback);
            pendingFallback = null;
        }
        SpeechRecognizer sr = recognizer;
        recognizer = null;
        if (sr != null) {
            try { sr.cancel(); } catch (RuntimeException ignored) { }
            try { sr.destroy(); } catch (RuntimeException ignored) { }
        }
        partial = "";
    }

    private static String best(Bundle results) {
        if (results == null) return "";
        ArrayList<String> alternatives = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        return alternatives == null || alternatives.isEmpty() ? "" : alternatives.get(0).trim();
    }

    private static String explainError(int error) {
        switch (error) {
            case SpeechRecognizer.ERROR_NO_MATCH: return "Je n'ai pas compris. Réessaie.";
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "Aucune parole détectée.";
            case SpeechRecognizer.ERROR_AUDIO: return "Erreur de capture audio.";
            case SpeechRecognizer.ERROR_CLIENT: return "Erreur du service vocal Android.";
            case SpeechRecognizer.ERROR_NETWORK: return "Le service de reconnaissance local signale un problème réseau ; aucune transcription cloud n'est autorisée.";
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "Délai expiré du service de reconnaissance.";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "Le service vocal est occupé.";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "Permission microphone refusée.";
            case SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED: return "Français non pris en charge par le moteur local.";
            case SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE: return "Modèle de reconnaissance française hors ligne absent.";
            default: return "Erreur de reconnaissance locale (code " + error + ").";
        }
    }

    private final class Session implements RecognitionListener {
        private final long id;
        Session(long id) { this.id = id; }
        private boolean valid() { return active && generation == id; }
        @Override public void onReadyForSpeech(Bundle params) { if (valid()) listener.onState("Je t'écoute…"); }
        @Override public void onBeginningOfSpeech() { if (valid()) listener.onState("Parole détectée…"); }
        @Override public void onRmsChanged(float rmsdB) { }
        @Override public void onBufferReceived(byte[] buffer) { }
        @Override public void onEndOfSpeech() {
            if (!valid()) return;
            listener.onState("Fin de phrase détectée…");
            if (!partial.trim().isEmpty()) scheduleFallback(1200L, id);
        }
        @Override public void onError(int error) {
            if (!valid()) return;
            if (!partial.trim().isEmpty() && (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT || error == SpeechRecognizer.ERROR_CLIENT)) {
                finishWithText(partial);
            } else finishWithError(explainError(error));
        }
        @Override public void onResults(Bundle results) {
            if (!valid()) return;
            String finalText = best(results);
            finishWithText(finalText.trim().isEmpty() ? partial : finalText);
        }
        @Override public void onPartialResults(Bundle partialResults) {
            if (!valid()) return;
            String candidate = best(partialResults);
            if (!candidate.trim().isEmpty()) {
                partial = candidate;
                listener.onPartial(candidate);
                scheduleFallback(2800L, id);
            }
        }
        @Override public void onEvent(int eventType, Bundle params) { }
    }
}
