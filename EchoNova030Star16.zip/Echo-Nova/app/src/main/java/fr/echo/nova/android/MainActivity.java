package fr.echo.nova.android;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import fr.echo.nova.core.CallState;
import fr.echo.nova.core.ChatLine;
import fr.echo.nova.core.DialogueEngine;
import fr.echo.nova.core.EchoLoopGuard;

import java.util.List;

/**
 * Minimal, original Android UI; no Compose, app compatibility library, cloud,
 * hidden TTS fallback or background microphone service required.
 */
public final class MainActivity extends Activity {
    private static final int MIC_PERMISSION_REQUEST = 101;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 102;
    private static final int BG = Color.rgb(9, 18, 31);
    private static final int SURFACE = Color.rgb(21, 35, 56);
    private static final int SURFACE_USER = Color.rgb(30, 64, 80);
    private static final int ACCENT = Color.rgb(137, 219, 205);
    private static final int TEXT = Color.rgb(242, 246, 250);
    private static final int SECONDARY = Color.rgb(172, 190, 206);

    private final Handler main = new Handler(Looper.getMainLooper());
    private final CallState call = new CallState();
    private final EchoLoopGuard loopGuard = new EchoLoopGuard();
    private ChatRepository repository;
    private DialogueEngine brain;
    private SpeechInput speech;
    private FrenchVoice voice;
    private ScrollView scroll;
    private LinearLayout transcript;
    private EditText entry;
    private TextView status;
    private TextView subtitle;
    private Button micButton;
    private Button callButton;
    private Button soundButton;
    private Button autoCallsButton;
    private boolean pendingIncomingAnswer;
    private boolean soundEnabled = true;
    private boolean foreground = false;
    private Runnable rearm;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        repository = new ChatRepository(this);
        brain = new DialogueEngine(repository);
        speech = new SpeechInput(this);
        soundEnabled = getPreferences(MODE_PRIVATE).getBoolean("speak", true);
        buildUi();
        voice = new FrenchVoice(this, value -> {
            if (!call.isInCall() && status != null) showStatus(value);
        });
        List<ChatLine> history = repository.recentMessages(100);
        if (history.isEmpty()) {
            repository.addMessage("assistant", "Bonjour ! Je suis Écho Nova, une nouvelle application indépendante. Écris-moi ou touche le micro. Pour mémoriser quelque chose, dis : « Souviens-toi que… ».");
            history = repository.recentMessages(100);
        }
        for (ChatLine line : history) appendBubble(line.role.equals("user"), line.text);
        scrollToBottom();
        showStatus("Prête pour les messages écrits. Le micro est exclusivement local.");
    }

    private void buildUi() {
        LinearLayout root = column();
        root.setBackgroundColor(BG);
        root.setFitsSystemWindows(true);
        root.setPadding(dp(16), dp(18), dp(16), dp(12));
        setContentView(root);

        LinearLayout bar = row();
        bar.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("◉", 28, ACCENT, true);
        bar.addView(logo, new LinearLayout.LayoutParams(dp(42), dp(40)));
        LinearLayout headings = column();
        TextView heading = text("ÉCHO NOVA", 22, TEXT, true);
        headings.addView(heading);
        subtitle = text("Indépendante · Hors ligne · v0.3.0 · Star 16", 12, SECONDARY, false);
        headings.addView(subtitle);
        bar.addView(headings, new LinearLayout.LayoutParams(0, -2, 1f));
        Button diag = action("Diagnostic", SURFACE, TEXT);
        diag.setOnClickListener(v -> showDiagnostics());
        bar.addView(diag);
        root.addView(bar);

        status = text("Initialisation…", 13, SECONDARY, false);
        status.setBackground(round(Color.rgb(14, 26, 44), dp(12)));
        status.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.setMargins(0, dp(14), 0, dp(12));
        root.addView(status, sp);

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        transcript = column();
        transcript.setPadding(0, dp(4), 0, dp(14));
        scroll.addView(transcript, new ScrollView.LayoutParams(-1, -2));
        LinearLayout actions = row();
        actions.setGravity(Gravity.CENTER_VERTICAL);
        callButton = action("Appeler", SURFACE, ACCENT);
        callButton.setContentDescription("Démarrer ou terminer une conversation vocale à l'écran");
        callButton.setOnClickListener(v -> toggleCall());
        actions.addView(callButton, new LinearLayout.LayoutParams(0, dp(50), 1f));
        View gap1 = new View(this);
        actions.addView(gap1, new LinearLayout.LayoutParams(dp(9), 1));
        soundButton = action(soundEnabled ? "Voix ON" : "Voix OFF", SURFACE, TEXT);
        soundButton.setOnClickListener(v -> toggleSound());
        actions.addView(soundButton, new LinearLayout.LayoutParams(0, dp(50), 1f));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, dp(50));
        ap.setMargins(0, dp(8), 0, dp(12));
        root.addView(actions, ap);

        // Model installation is explicit, and a test allows checking the exact voice
        // without having to start an incoming call or rely on the rule-based brain.
        LinearLayout voiceOptions = row();
        voiceOptions.setGravity(Gravity.CENTER_VERTICAL);
        Button prepareVoice = action("Installer Star 16", SURFACE, ACCENT);
        prepareVoice.setOnClickListener(v -> {
            if (voice != null) voice.prepareStar16();
            else showStatus("Moteur vocal en cours de démarrage.");
        });
        voiceOptions.addView(prepareVoice, new LinearLayout.LayoutParams(0, dp(50), 1f));
        View voiceGap = new View(this);
        voiceOptions.addView(voiceGap, new LinearLayout.LayoutParams(dp(9), 1));
        Button testVoice = action("Tester Star 16", SURFACE, TEXT);
        testVoice.setOnClickListener(v -> {
            if (voice == null || !voice.star16Active()) {
                showStatus("Star 16 pas prête : touche « Installer Star 16 » puis réessaie.");
                return;
            }
            if (call.isInCall()) endCall();
            if (speech != null) speech.cancel();
            showStatus("Écoute de Star 16 en français…");
            String sample = "Bon, je vais être franche avec toi. Ton raisonnement n'est pas complètement faux, mais tu oublies un détail assez important.";
            boolean started = voice.speak(sample, (ok, explanation) -> {
                showStatus(ok ? "Test Star 16 terminé. " + voice.status() : "Échec Star 16 : " + explanation);
            });
            if (!started) showStatus("Impossible de lancer Star 16. Voir Diagnostic.");
        });
        voiceOptions.addView(testVoice, new LinearLayout.LayoutParams(0, dp(50), 1f));
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, dp(50));
        vp.setMargins(0, 0, 0, dp(10));
        root.addView(voiceOptions, vp);

        LinearLayout incomingOptions = row();
        incomingOptions.setGravity(Gravity.CENTER_VERTICAL);
        Button callTest = action("Tester appel entrant", SURFACE, ACCENT);
        callTest.setOnClickListener(v -> {
            if (!IncomingCalls.notificationsAllowed(this)) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
                showStatus("Autorise les notifications, puis réessaie le test.");
                return;
            }
            showStatus(IncomingCalls.showIncoming(this)
                ? "Invitation d'appel envoyée. Tu peux accepter ou refuser."
                : "Notification indisponible : vérifie les autorisations Android.");
        });
        incomingOptions.addView(callTest, new LinearLayout.LayoutParams(0, dp(50), 1f));
        View gap2 = new View(this);
        incomingOptions.addView(gap2, new LinearLayout.LayoutParams(dp(9), 1));
        autoCallsButton = action(IncomingCalls.enabled(this) ? "Auto ON" : "Auto OFF", SURFACE, TEXT);
        autoCallsButton.setOnClickListener(v -> toggleAutomaticCalls());
        incomingOptions.addView(autoCallsButton, new LinearLayout.LayoutParams(0, dp(50), 1f));
        LinearLayout.LayoutParams incp = new LinearLayout.LayoutParams(-1, dp(50));
        incp.setMargins(0, 0, 0, dp(10));
        root.addView(incomingOptions, incp);

        // Voice calls are the primary action; text history is secondary.
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout inputBar = row();
        inputBar.setGravity(Gravity.CENTER_VERTICAL);
        inputBar.setBackground(round(SURFACE, dp(18)));
        inputBar.setPadding(dp(7), dp(5), dp(7), dp(5));

        micButton = action("Micro", Color.rgb(28, 48, 72), ACCENT);
        micButton.setContentDescription("Écouter en français hors ligne");
        micButton.setOnClickListener(v -> onMicrophonePressed());
        inputBar.addView(micButton, new LinearLayout.LayoutParams(dp(74), dp(50)));

        entry = new EditText(this);
        entry.setSingleLine(false);
        entry.setMaxLines(3);
        entry.setTextColor(TEXT);
        entry.setHintTextColor(SECONDARY);
        entry.setHint("Écris un message…");
        entry.setTextSize(15);
        entry.setBackgroundColor(Color.TRANSPARENT);
        entry.setPadding(dp(9), dp(4), dp(7), dp(4));
        entry.setImeOptions(EditorInfo.IME_ACTION_SEND);
        entry.setOnEditorActionListener((view, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) { sendTyped(); return true; }
            return false;
        });
        inputBar.addView(entry, new LinearLayout.LayoutParams(0, -2, 1f));
        Button send = action("Envoyer", ACCENT, BG);
        send.setOnClickListener(v -> sendTyped());
        inputBar.addView(send, new LinearLayout.LayoutParams(dp(86), dp(50)));
        root.addView(inputBar);

        TextView note = text("Les données restent dans cette application. Aucune permission Internet.", 11, SECONDARY, false);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.setMargins(0, dp(9), 0, 0);
        root.addView(note, np);
    }

    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private int dp(int n) { return (int) (n * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable round(int fill, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(radius);
        return d;
    }
    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(sp);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private Button action(String value, int bg, int fg) {
        Button b = new Button(this);
        b.setText(value);
        b.setAllCaps(false);
        b.setTextColor(fg);
        b.setTextSize(12);
        b.setPadding(dp(7), 0, dp(7), 0);
        b.setBackground(round(bg, dp(14)));
        return b;
    }

    private void appendBubble(boolean user, String content) {
        LinearLayout wrap = column();
        wrap.setGravity(user ? Gravity.END : Gravity.START);
        LinearLayout.LayoutParams outer = new LinearLayout.LayoutParams(-1, -2);
        outer.setMargins(user ? dp(28) : 0, dp(6), user ? 0 : dp(28), dp(6));
        TextView author = text(user ? "TOI" : "ÉCHO NOVA", 10, user ? ACCENT : SECONDARY, true);
        LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(-2, -2);
        al.setMargins(dp(7), 0, dp(7), dp(4));
        wrap.addView(author, al);
        TextView message = text(content, 15, TEXT, false);
        message.setTextIsSelectable(true);
        message.setPadding(dp(14), dp(12), dp(14), dp(12));
        message.setBackground(round(user ? SURFACE_USER : SURFACE, dp(16)));
        wrap.addView(message);
        transcript.addView(wrap, outer);
        scrollToBottom();
    }

    private void scrollToBottom() { if (scroll != null) scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN)); }
    private void showStatus(String value) { if (status != null) status.setText(value); }

    private void sendTyped() {
        String question = entry.getText().toString().trim();
        if (question.isEmpty()) return;
        if (question.length() > 1800) { showStatus("Message trop long : 1 800 caractères maximum."); return; }
        if (processQuestion(question)) {
            entry.setText("");
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(entry.getWindowToken(), 0);
        }
    }

    private boolean processQuestion(String question) {
        if (rearm != null) main.removeCallbacks(rearm);
        speech.cancel();
        micButton.setText("Micro");
        if (voice != null) voice.stop();
        try {
            call.onThinking();
            repository.addMessage("user", question);
            appendBubble(true, question);
            showStatus("Réponse locale en cours…");
            String response = brain.reply(question);
            repository.addMessage("assistant", response);
            appendBubble(false, response);
            if (soundEnabled && voice != null && voice.available()) {
                call.onSpeaking();
                showStatus("Écho parle…");
                loopGuard.spoke(response);
                boolean started = voice.speak(response, (ok, error) -> {
                    call.onTurnFinished();
                    showStatus(ok ? "À ton tour." : "Erreur vocale : " + error);
                    if (ok) maybeRearm();
                });
                if (!started) {
                    call.onTurnFinished();
                    showStatus("La réponse est écrite, mais le moteur vocal n'a pas démarré.");
                }
            } else {
                call.onTurnFinished();
                showStatus(soundEnabled ? "Réponse écrite prête. " + (voice == null ? "Voix en cours de chargement." : voice.status()) : "Réponse écrite prête. Voix désactivée.");
            }
            return true;
        } catch (RuntimeException ex) {
            showStatus("Erreur de conversation : " + ex.getClass().getSimpleName() + ". Le texte saisi reste dans l'historique s'il a été enregistré.");
            call.onTurnFinished();
            return false;
        }
    }

    private void maybeRearm() {
        if (!call.isInCall() || !foreground || !soundEnabled) return;
        rearm = () -> {
            if (call.isInCall() && foreground) beginListening();
        };
        main.postDelayed(rearm, 1100L);
    }

    private void toggleAutomaticCalls() {
        boolean enable = !IncomingCalls.enabled(this);
        if (enable && !IncomingCalls.notificationsAllowed(this)) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
            showStatus("Autorise les notifications, puis active Auto ON.");
            return;
        }
        IncomingCalls.setEnabled(this, enable);
        autoCallsButton.setText(enable ? "Auto ON" : "Auto OFF");
        showStatus(enable ? "Invitations vocales activées. " + IncomingCalls.nextText(this)
                : "Invitations spontanées désactivées. Aucun appel automatique.");
    }

    private void processSpokenQuestion(String heard) {
        if (!loopGuard.accept(heard, System.currentTimeMillis())) {
            showStatus("Possible écho acoustique ou transcription répétée ignorée.");
            call.onTurnFinished();
            if (call.isInCall()) maybeRearm();
            return;
        }
        processQuestion(heard);
    }

    private void onMicrophonePressed() {
        if (speech.isListening()) { speech.stopAndAcceptPartial(); return; }
        if (voice != null) voice.stop();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_PERMISSION_REQUEST);
            return;
        }
        beginListening();
    }

    private void beginListening() {
        if (!foreground) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            showStatus("Autorise le microphone pour parler à Écho.");
            return;
        }
        if (!speech.available()) {
            showStatus("Aucun moteur de reconnaissance locale disponible : vérifie les paramètres Android de saisie vocale française.");
            if (call.isInCall()) endCall();
            return;
        }
        if (voice != null) voice.stop();
        call.onListening();
        micButton.setText("Stop");
        speech.start(new SpeechInput.Listener() {
            @Override public void onState(String value) { showStatus(value); }
            @Override public void onPartial(String value) { showStatus("Entendu : « " + value + " » (provisoire)"); }
            @Override public void onFinal(String value) { micButton.setText("Micro"); processSpokenQuestion(value); }
            @Override public void onFailure(String value) {
                micButton.setText("Micro");
                showStatus(value);
                call.onTurnFinished();
                // Silence is normal: listen again with a gap, not an immediate busy loop.
                if (call.isInCall() && (value.contains("Aucune parole") || value.contains("pas compris"))) {
                    rearm = () -> { if (foreground && call.isInCall()) beginListening(); };
                    main.postDelayed(rearm, 1400L);
                    return;
                }
                if (call.isInCall()) {
                    call.endCall();
                    callButton.setText("Appeler");
                    showStatus(value + " Appel arrêté : touche « Appeler » pour réessayer.");
                }
            }
        });
    }

    private void toggleCall() {
        if (call.isInCall()) { endCall(); return; }
        startCall(false);
    }

    private void startCall(boolean incoming) {
        if (call.isInCall()) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_PERMISSION_REQUEST);
            showStatus("Autorise le micro puis touche « Appeler » à nouveau.");
            return;
        }
        if (!speech.available()) { showStatus("Appel non lancé : reconnaissance française hors ligne indisponible."); return; }
        if (!soundEnabled || voice == null || !voice.available()) { showStatus("Appel non lancé : vérifie la voix française hors ligne dans Diagnostic."); return; }
        call.startCall();
        callButton.setText("Raccrocher");
        if (incoming) {
            final String greeting = "Salut. J'avais envie de discuter un peu avec toi. Tu as un moment ?";
            loopGuard.spoke(greeting);
            call.onSpeaking();
            showStatus("Écho te salue…");
            boolean started = voice.speak(greeting, (ok, explanation) -> {
                call.onTurnFinished();
                if (foreground && call.isInCall()) beginListening();
            });
            if (!started) { call.onTurnFinished(); beginListening(); }
        } else {
            showStatus("Conversation vocale démarrée · Je t'écoute…");
            beginListening();
        }
    }

    private void endCall() {
        call.endCall();
        if (rearm != null) main.removeCallbacks(rearm);
        speech.cancel();
        if (voice != null) voice.stop();
        micButton.setText("Micro");
        callButton.setText("Appeler");
        showStatus("Appel terminé. Tu peux toujours écrire.");
    }

    private void toggleSound() {
        soundEnabled = !soundEnabled;
        getPreferences(MODE_PRIVATE).edit().putBoolean("speak", soundEnabled).apply();
        soundButton.setText(soundEnabled ? "Voix ON" : "Voix OFF");
        if (!soundEnabled && voice != null) voice.stop();
        if (!soundEnabled && call.isInCall()) endCall();
        showStatus(soundEnabled ? "Synthèse vocale activée. " + (voice == null ? "Initialisation…" : voice.status()) : "Synthèse vocale désactivée : mode texte disponible.");
    }

    private void showDiagnostics() {
        int memories = repository.recallRecent(25).size();
        boolean speechReady = speech.available();
        String details = "Version : 0.3.0 · Star 16 (alpha)\n" +
            "Application ID : fr.echo.nova.star16\n" +
            "Identité de signature : indépendante d'Écho 4.0.0 (release : voir certificat)\n\n" +
            "Moteur de dialogue : règles locales (PAS de LLM installé)\n" +
            "Messages persistants : " + repository.recentMessages(200).size() + " (200 derniers affichables)\n" +
            "Souvenirs explicites : " + memories + (memories == 25 ? " ou plus" : "") + "\n" +
            "Reconnaissance Android 100 % locale : " + (speechReady ? "service disponible (français à tester)" : "indisponible") + "\n" +
            "Permission microphone : " + (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED ? "accordée" : "non accordée") + "\n" +
            "Voix : " + (voice == null ? "en attente" : voice.status()) + "\n" +
            "Star 16 active : " + (voice != null && voice.star16Active() ? "oui" : "non, secours Android si disponible") + "\n" +
            "Latence du premier son Star 16 : " + (voice == null || voice.star16Latency() < 0 ? "pas encore mesurée" : voice.star16Latency() + " ms") + "\n" +
            "Permission INTERNET : absente\n" +
            "Appel téléphonique réel : non (conversation à l'écran uniquement)\n" +
            "Invitations spontanées : " + IncomingCalls.nextText(this) + "\n" +
            "Notifications : " + (IncomingCalls.notificationsAllowed(this) ? "autorisées" : "refusées") + "\n" +
            "Appel entrant : notification simulée, pas d'appel téléphonique réel\n\n" +
            "Les moteurs Android peuvent nécessiter l'installation préalable de données françaises. Leurs performances sur Pixel 8 restent à valider.";
        new AlertDialog.Builder(this)
            .setTitle("Diagnostics Écho Nova")
            .setMessage(details)
            .setPositiveButton("Fermer", null)
            .setNeutralButton("Copier", (dialog, which) -> {
                ClipboardManager manager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                manager.setPrimaryClip(ClipData.newPlainText("Écho Nova diagnostics", details));
                showStatus("Diagnostic copié.");
            })
            .setNegativeButton("Effacer les données", (dialog, which) -> confirmErase())
            .show();
    }

    private void confirmErase() {
        new AlertDialog.Builder(this)
            .setTitle("Tout effacer ?")
            .setMessage("Cette action supprimera définitivement l'historique et les souvenirs d'Écho Nova uniquement. Écho 4.0.0 ne sera pas affectée.")
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Effacer", (dialog, which) -> {
                endCall();
                repository.eraseAll();
                transcript.removeAllViews();
                repository.addMessage("assistant", "Mémoire et historique d'Écho Nova effacés. Nous repartons de zéro.");
                appendBubble(false, "Mémoire et historique d'Écho Nova effacés. Nous repartons de zéro.");
            })
            .show();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MIC_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) beginListening();
            else showStatus("Microphone refusé. Tu peux toujours utiliser le clavier.");
        }
        if (requestCode == NOTIFICATION_PERMISSION_REQUEST) {
            showStatus(IncomingCalls.notificationsAllowed(this)
                    ? "Notifications autorisées. Tu peux tester un appel ou activer Auto ON."
                    : "Notifications refusées : les invitations d'appel sont indisponibles.");
        }
    }

    @Override protected void onResume() {
        super.onResume();
        foreground = true;
        if (IncomingCalls.ACTION_ACCEPT.equals(getIntent().getAction())) {
            getIntent().setAction(null);
            IncomingCalls.dismiss(this);
            main.postDelayed(() -> { if (foreground && !call.isInCall()) startCall(true); }, 1500L);
        }
    }

    @Override protected void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (IncomingCalls.ACTION_ACCEPT.equals(intent.getAction())) {
            intent.setAction(null);
            IncomingCalls.dismiss(this);
            main.postDelayed(() -> { if (foreground && !call.isInCall()) startCall(true); }, 1500L);
        }
    }

    @Override protected void onStop() {
        // No background recording: protects privacy and avoids microphone lifecycle leaks.
        foreground = false;
        if (rearm != null) main.removeCallbacks(rearm);
        speech.cancel();
        if (voice != null) voice.stop();
        call.endCall();
        if (micButton != null) micButton.setText("Micro");
        if (callButton != null) callButton.setText("Appeler");
        super.onStop();
    }

    @Override protected void onDestroy() {
        if (voice != null) voice.shutdown();
        if (repository != null) repository.close();
        super.onDestroy();
    }
}
