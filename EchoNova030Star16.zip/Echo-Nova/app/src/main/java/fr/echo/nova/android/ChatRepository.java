package fr.echo.nova.android;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import fr.echo.nova.core.ChatLine;
import fr.echo.nova.core.MemoryStore;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Separate database name and Android application ID from Écho 4.0.0. */
public final class ChatRepository extends SQLiteOpenHelper implements MemoryStore {
    private static final String DB_NAME = "echo_nova_private.db";
    private static final int DB_VERSION = 1;

    public ChatRepository(Context context) {
        super(context.getApplicationContext(), DB_NAME, null, DB_VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE messages (id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL, body TEXT NOT NULL, ts INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE memories (id INTEGER PRIMARY KEY AUTOINCREMENT, body TEXT NOT NULL, ts INTEGER NOT NULL)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Non-destructive migrations must be implemented when schema version advances.
        throw new IllegalStateException("Database migration needed from " + oldVersion + " to " + newVersion);
    }

    public synchronized void addMessage(String role, String body) {
        if (!role.equals("user") && !role.equals("assistant")) throw new IllegalArgumentException("Invalid role");
        if (body == null || body.trim().isEmpty()) return;
        ContentValues values = new ContentValues();
        values.put("role", role);
        values.put("body", body);
        values.put("ts", System.currentTimeMillis());
        getWritableDatabase().insertOrThrow("messages", null, values);
    }

    public synchronized List<ChatLine> recentMessages(int limit) {
        int count = Math.max(1, Math.min(200, limit));
        List<ChatLine> reversed = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT id, role, body, ts FROM messages ORDER BY id DESC LIMIT " + count, null)) {
            while (cursor.moveToNext()) {
                reversed.add(new ChatLine(cursor.getLong(0), cursor.getString(1), cursor.getString(2), cursor.getLong(3)));
            }
        }
        Collections.reverse(reversed);
        return reversed;
    }

    @Override public synchronized void remember(String information) {
        if (information == null || information.trim().isEmpty() || information.length() > 600) return;
        ContentValues values = new ContentValues();
        values.put("body", information);
        values.put("ts", System.currentTimeMillis());
        getWritableDatabase().insertOrThrow("memories", null, values);
    }

    @Override public synchronized List<String> recallRecent(int limit) {
        int count = Math.max(1, Math.min(25, limit));
        List<String> facts = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT body FROM memories ORDER BY id DESC LIMIT " + count, null)) {
            while (cursor.moveToNext()) facts.add(cursor.getString(0));
        }
        return facts;
    }

    @Override public synchronized void forgetAll() {
        getWritableDatabase().delete("memories", null, null);
    }

    public synchronized void eraseAll() {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("messages", null, null);
            db.delete("memories", null, null);
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }
}
