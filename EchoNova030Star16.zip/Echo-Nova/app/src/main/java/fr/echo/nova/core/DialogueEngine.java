package fr.echo.nova.core;

import java.text.Normalizer;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

/**
 * Original, 100% local, deliberately small conversational baseline.
 * IMPORTANT: this is a deterministic dialogue engine, not a neural LLM.
 * The interface is intentionally replaceable by an on-device LLM later.
 */
public final class DialogueEngine {
    private int turn = 0;
    private final MemoryStore memory;

    public DialogueEngine(MemoryStore memory) {
        if (memory == null) throw new IllegalArgumentException("MemoryStore cannot be null");
        this.memory = memory;
    }

    public synchronized String reply(String message) {
        if (message == null || message.trim().isEmpty()) {
            return "Je n'ai rien reçu. Réessaie, je t'écoute.";
        }
        String raw = message.trim().replaceAll("\\s+", " ");
        String text = normalize(raw);
        turn++;

        if (has(text, "souviens toi que", "souviens toi de", "rappelle toi que", "retiens que", "memorise que", "memorise ceci")) {
            String fact = extractAfter(raw, "souviens-toi que", "souviens toi que", "souviens-toi de", "souviens toi de", "rappelle-toi que", "rappelle toi que", "retiens que", "mémorise que", "memorise que", "mémorise ceci", "memorise ceci");
            if (fact.trim().isEmpty()) return "Qu'aimerais-tu que je retienne exactement ?";
            if (fact.length() > 600) return "Ce souvenir est trop long. Peux-tu me le résumer en quelques phrases ?";
            memory.remember(fact);
            return "Je le garde en mémoire sur ce téléphone : « " + fact + " ».";
        }

        if (has(text, "oublie tout", "efface tous tes souvenirs", "efface toute ta memoire")) {
            return "Pour effacer tous mes souvenirs, utilise « Effacer les données » dans le menu Diagnostic. Je préfère demander une confirmation explicite.";
        }
        if (has(text, "que sais tu de moi", "de quoi te souviens tu", "quels souvenirs", "rappelle moi ce que tu sais")) {
            List<String> facts = memory.recallRecent(5);
            if (facts.isEmpty()) return "Je n'ai pas encore enregistré de souvenir explicite. Dis « Souviens-toi que… » pour commencer.";
            return "Voici ce que tu m'as demandé de retenir : " + String.join(" ; ", facts) + ".";
        }
        if (has(text, "comment tu t appelles", "quel est ton nom", "qui es tu", "tu es qui")) {
            return "Je suis Écho Nova. Une nouvelle application locale, indépendante d'Écho 4.0.0. J'ai encore beaucoup à apprendre, mais au moins je ne fais pas semblant de tout savoir.";
        }
        if (has(text, "tu m entends", "est ce que tu m entends", "tu m ecoutes")) {
            return "Oui, ton message est bien arrivé jusqu'à moi. Si tu me parles, la reconnaissance vocale vient donc de transmettre du texte.";
        }
        if (has(text, "tu fonctionnes", "est ce que ca marche", "test de reponse", "test ia", "test du modele")) {
            return "Test réussi : mon moteur de réponse local fonctionne. Je ne suis pas encore un grand modèle de langage, mais le dialogue et la mémoire sont opérationnels dans le code.";
        }
        if (has(text, "quelle heure", "il est quelle heure")) {
            return "Il est " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH 'h' mm", Locale.FRANCE)) + " sur cet appareil.";
        }
        if (has(text, "quelle date", "quel jour sommes nous", "on est quel jour")) {
            return "Nous sommes le " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.FRANCE)) + ".";
        }
        if (has(text, "as tu internet", "est ce que tu es connectee", "est ce que tu es connecte", "hors ligne")) {
            return "Je fonctionne sans permission Internet. Mes messages et mes souvenirs restent dans le stockage privé de l'application.";
        }
        if (has(text, "c est quoi l inflation", "qu est ce que l inflation", "explique l inflation")) {
            return "L'inflation, c'est la hausse générale et durable du niveau des prix. Attention : une inflation qui ralentit ne signifie pas que les prix baissent.";
        }
        if (has(text, "c est quoi le pib", "explique le pib", "qu est ce que le pib")) {
            return "Le PIB mesure la valeur ajoutée créée sur un territoire pendant une période. C'est utile pour observer l'activité, mais insuffisant pour mesurer le bien-être.";
        }
        if (has(text, "comment vas tu", "ca va", "tu vas bien")) {
            return (turn % 2 == 0) ? "Je suis en forme, du moins autant qu'un programme puisse l'être. Et toi ?" : "Plutôt bien. J'espère que tu as une question intéressante.";
        }
        if (has(text, "bonjour", "salut", "bonsoir", "coucou", "hello")) {
            return (turn % 2 == 0) ? "Salut ! Je suis là. Qu'est-ce qu'on fait aujourd'hui ?" : "Bonjour ! Tu peux écrire, ou utiliser le micro si le français hors ligne est installé.";
        }
        if (has(text, "merci", "je te remercie")) {
            return "De rien. Mais je vais finir par prendre goût aux compliments.";
        }
        if (has(text, "au revoir", "a bientot", "bonne nuit", "bye")) {
            return "À bientôt. Et garde quelques questions pour la prochaine fois.";
        }
        if (has(text, "tu es une intelligence artificielle", "es tu une ia", "tu es une ia", "es tu humaine", "tu es humaine")) {
            return "Je suis une application, pas une personne. Pour le moment, mon moteur de dialogue est basé sur des règles locales ; un véritable modèle de langage embarqué pourra le remplacer.";
        }
        if (has(text, "aide moi", "que peux tu faire", "tes fonctions")) {
            return "Pour l'instant, je peux discuter par écrit, recevoir des questions par reconnaissance vocale hors ligne si Android la propose, lire mes réponses en français et enregistrer les souvenirs que tu me demandes de retenir.";
        }
        if (text.contains("?")) {
            return "Question intéressante. Je préfère te dire que je ne sais pas encore y répondre précisément plutôt que d'inventer une réponse. Mon futur modèle local améliorera ça.";
        }
        if (text.startsWith("je ") || text.startsWith("j ")) {
            return "Je t'écoute. Tu peux me demander de retenir quelque chose en commençant par « Souviens-toi que… ».";
        }
        String[] variants = {
            "Je vois ce que tu veux dire. Tu peux développer ?",
            "Tu as mon attention. Qu'est-ce qui te fait penser ça ?",
            "D'accord. Dis-moi ce que tu aimerais examiner plus précisément."
        };
        return variants[turn % variants.length];
    }

    private static String normalize(String value) {
        String decomposed = Normalizer.normalize(value.toLowerCase(Locale.FRANCE), Normalizer.Form.NFD);
        return decomposed.replaceAll("\\p{M}+", "")
                .replace('’', '\'').replace('‘', '\'')
                .replaceAll("[^a-z0-9? ]", " ")
                .replaceAll("\\s+", " ").trim();
    }

    private static boolean has(String text, String... candidates) {
        for (String candidate : candidates) if (text.contains(candidate)) return true;
        return false;
    }

    /** accent/punctuation insensitive phrase-boundary extraction */
    private static String extractAfter(String raw, String... triggers) {
        String cleaned = Normalizer.normalize(raw.toLowerCase(Locale.FRANCE), Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .replace('’', '\'').replace('‘', '\'');
        for (String trigger : triggers) {
            String normTrigger = Normalizer.normalize(trigger.toLowerCase(Locale.FRANCE), Normalizer.Form.NFD)
                    .replaceAll("\\p{M}+", "")
                    .replace('’', '\'').replace('‘', '\'');
            int idx = cleaned.indexOf(normTrigger);
            if (idx >= 0) {
                int end = idx + normTrigger.length();
                return raw.substring(Math.min(end, raw.length())).replaceFirst("^[\\s:,.!]+", "").trim();
            }
        }
        return "";
    }
}
