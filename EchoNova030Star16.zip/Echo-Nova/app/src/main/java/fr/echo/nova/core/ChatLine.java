package fr.echo.nova.core;

public final class ChatLine {
    public final long id;
    public final String role;
    public final String text;
    public final long timestamp;

    public ChatLine(long id, String role, String text, long timestamp) {
        this.id = id;
        this.role = role;
        this.text = text;
        this.timestamp = timestamp;
    }
}
