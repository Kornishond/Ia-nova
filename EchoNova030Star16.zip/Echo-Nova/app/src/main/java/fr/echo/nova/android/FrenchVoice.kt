package fr.echo.nova.android

import android.content.Context
import android.media.AudioAttributes
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.google.mlkit.genai.common.DownloadStatus
import com.google.mlkit.genai.common.FeatureStatus
import com.google.mlkit.genai.texttospeech.SpeechSynthesis
import com.google.mlkit.genai.texttospeech.SpeechSynthesizer
import com.google.mlkit.genai.texttospeech.SpeechSynthesizerOptions
import com.google.mlkit.genai.texttospeech.SpeechSynthesizerRequest
import com.google.mlkit.genai.texttospeech.SpeechSynthesizerResponse
import com.google.mlkit.genai.texttospeech.VoiceInfo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * On-device French TTS. Prefers the exact generative voice star16/fr-FR.
 * The platform Android French TTS is a clearly labelled offline fallback only.
 * Star16 model download requires explicit user action; ML Kit manages the assets.
 * Public methods/callbacks remain compatible with Java MainActivity.
 */
class FrenchVoice(context: Context, private val readyListener: ReadyListener) {
    fun interface ReadyListener { fun onStatusChanged(status: String) }
    fun interface FinishedListener { fun onFinished(spoken: Boolean, explanation: String) }

    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var synth: SpeechSynthesizer? = null
    private var starVoice: VoiceInfo? = null
    private var starReady: Boolean = false
    private var backup: TextToSpeech? = null
    private var backupReady: Boolean = false
    private var downloadJob: Job? = null
    private var speakJob: Job? = null
    private var currentCallback: FinishedListener? = null
    private var generation: Long = 0L
    private var lastLatencyMs: Long = -1L
    private var pendingDownload = false
    private var destroyed = false
    private var state: String = "Recherche de Star 16 (français)…"

    init {
        // Start the legacy engine in parallel: only the locally installed French voice is accepted.
        backup = TextToSpeech(appContext) { result -> main.post { configureBackup(result) } }
        probeStar16()
    }

    private fun update(message: String) {
        if (destroyed) return
        state = message
        readyListener.onStatusChanged(message)
    }

    private fun probeStar16() {
        scope.launch {
            try {
                if (synth == null) {
                    synth = SpeechSynthesis.getClient(
                        SpeechSynthesizerOptions.Builder(Locale.FRANCE)
                            .setVoiceFallbackEnabled(false)
                            .build()
                    )
                }
                val client = synth ?: return@launch
                val voices = client.getSupportedVoices(Locale.FRANCE)
                val exact = voices.firstOrNull { it.name.equals("star16", ignoreCase = true) }
                if (exact == null) {
                    starReady = false
                    update("Star 16 fr-FR non proposée. Mets à jour Reconnaissance et synthèse vocales Google ; secours Android disponible si installé.")
                    return@launch
                }
                starVoice = exact
                when (client.checkStatus(exact)) {
                    FeatureStatus.AVAILABLE -> {
                        starReady = true
                        update("Star 16 française prête — voix générative locale active.")
                        pendingDownload = false
                    }
                    FeatureStatus.DOWNLOADABLE -> {
                        starReady = false
                        update("Star 16 disponible : touche « Installer Star 16 » pour télécharger sa voix.")
                        if (pendingDownload) doDownload(exact)
                    }
                    FeatureStatus.DOWNLOADING -> {
                        starReady = false
                        update("Star 16 : téléchargement déjà en cours. Réessaie après quelques instants.")
                    }
                    else -> {
                        starReady = false
                        update("Star 16 indisponible dans les services vocaux Google. Mets-les à jour puis retente.")
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                starReady = false
                update("Star 16 : ${e.javaClass.simpleName}. Vérifie les services vocaux Google.")
            } catch (e: LinkageError) {
                starReady = false
                update("API Star 16 non disponible : ${e.javaClass.simpleName}.")
            }
        }
    }

    /** Explicit user-requested download, never background-download an unknown-size model. */
    fun prepareStar16() {
        if (destroyed) return
        if (starReady) { update("Star 16 française est déjà installée et active."); return }
        pendingDownload = true
        val voice = starVoice
        if (voice == null) {
            update("Vérification de Star 16…")
            probeStar16()
        } else {
            doDownload(voice)
        }
    }

    private fun doDownload(voice: VoiceInfo) {
        if (downloadJob?.isActive == true || destroyed) return
        downloadJob = scope.launch {
            val client = synth ?: return@launch
            try {
                when (client.checkStatus(voice)) {
                    FeatureStatus.AVAILABLE -> {
                        starReady = true
                        pendingDownload = false
                        update("Star 16 française prête — voix générative locale active.")
                        return@launch
                    }
                    FeatureStatus.DOWNLOADABLE -> Unit
                    else -> {
                        update("Star 16 ne peut pas encore être téléchargée. Vérifie Google Speech Services.")
                        return@launch
                    }
                }
                update("Téléchargement de la voix Star 16… Garde une connexion pour cette installation initiale.")
                var failed = false
                client.download(voice).collect { event ->
                    when (event) {
                        is DownloadStatus.DownloadCompleted -> update("Téléchargement de Star 16 terminé ; vérification…")
                        is DownloadStatus.DownloadFailed -> {
                            failed = true
                            update("Téléchargement de Star 16 échoué. Réessaie avec Internet activé.")
                        }
                        else -> Unit
                    }
                }
                if (!failed && client.checkStatus(voice) == FeatureStatus.AVAILABLE) {
                    starReady = true
                    pendingDownload = false
                    update("Star 16 française prête — essaie « Tester Star 16 » !")
                } else if (!failed) {
                    update("Star 16 n'est pas encore prête. Touche Installer pour revérifier.")
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                update("Téléchargement Star 16 : ${e.javaClass.simpleName}.")
            }
        }
    }

    private fun configureBackup(result: Int) {
        if (destroyed) return
        val tts = backup ?: return
        if (result != TextToSpeech.SUCCESS) return
        try {
            val lang = tts.setLanguage(Locale.FRANCE)
            if (lang == TextToSpeech.LANG_NOT_SUPPORTED || lang == TextToSpeech.LANG_MISSING_DATA) return
            val chosen: Voice = tts.voices?.filter { voice ->
                voice.locale.language.equals("fr", ignoreCase = true) && !voice.isNetworkConnectionRequired
            }?.maxByOrNull { v -> v.quality * 10 + if (v.locale.country.equals("FR", true)) 5 else 0 }
                ?: return
            if (tts.setVoice(chosen) != TextToSpeech.SUCCESS) return
            tts.setSpeechRate(.97f)
            tts.setPitch(1.03f)
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit
                override fun onDone(utteranceId: String?) {
                    main.post { completeLegacy(utteranceId, true, "") }
                }
                override fun onError(utteranceId: String?) {
                    main.post { completeLegacy(utteranceId, false, "Erreur de synthèse Android.") }
                }
                override fun onError(utteranceId: String?, errorCode: Int) {
                    main.post { completeLegacy(utteranceId, false, "Erreur TTS Android : $errorCode") }
                }
            })
            backupReady = true
            if (!starReady && starVoice == null) update("Voix Android locale disponible en secours ; recherche de Star 16…")
        } catch (_: RuntimeException) { backupReady = false }
    }

    fun status(): String = state
    fun star16Active(): Boolean = starReady
    fun star16Latency(): Long = lastLatencyMs
    fun available(): Boolean = starReady || backupReady

    fun speak(text: String?, listener: FinishedListener): Boolean {
        if (destroyed || text.isNullOrBlank()) return false
        stop()
        val token = generation
        currentCallback = listener
        val client = synth
        val voice = starVoice
        if (starReady && client != null && voice != null) {
            speakJob = scope.launch {
                val before = SystemClock.elapsedRealtime()
                var firstAudio = false
                var done = false
                var error: String? = null
                try {
                    val request = SpeechSynthesizerRequest(
                        input = SpeechSynthesizerRequest.Input.Text(text, voice),
                        audioAttributes = AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    client.synthesize(request).collect { response ->
                        when (response) {
                            is SpeechSynthesizerResponse.AudioAvailable -> {
                                if (!firstAudio) {
                                    firstAudio = true
                                    val ms = SystemClock.elapsedRealtime() - before
                                    lastLatencyMs = ms
                                    update("Star 16 : premier audio après ${ms} ms (génération vocale uniquement).")
                                }
                            }
                            is SpeechSynthesizerResponse.StatusUpdate -> {
                                if (response.status == SpeechSynthesizerResponse.Status.DONE) done = true
                            }
                            is SpeechSynthesizerResponse.Error -> error = "Erreur ML Kit : ${response.errorCode}"
                        }
                    }
                    if (generation == token) finish(token, error == null && (done || firstAudio), error ?: "Aucune donnée vocale fournie.")
                } catch (e: CancellationException) { throw e }
                catch (e: Exception) { finish(token, false, "Star 16 : ${e.javaClass.simpleName}.") }
                catch (e: LinkageError) { finish(token, false, "Bibliothèque Star 16 indisponible.") }
            }
            return true
        }
        // Fallback is intentionally explicit in diagnostics: don't misrepresent it as Star 16.
        if (backupReady) {
            val started = backup?.speak(text, TextToSpeech.QUEUE_FLUSH, null, token.toString()) == TextToSpeech.SUCCESS
            if (started) update("Voix Android de secours utilisée : Star 16 pas encore installée.")
            if (!started) currentCallback = null
            return started
        }
        currentCallback = null
        update("Aucune voix française prête. Installe Star 16 avec le bouton dédié.")
        return false
    }

    private fun completeLegacy(id: String?, ok: Boolean, explanation: String) {
        if (id != generation.toString()) return
        finish(generation, ok, explanation)
    }

    private fun finish(token: Long, ok: Boolean, explanation: String) {
        if (destroyed || token != generation) return
        val listener = currentCallback ?: return
        currentCallback = null
        listener.onFinished(ok, explanation)
    }

    fun stop() {
        ++generation
        currentCallback = null
        speakJob?.cancel()
        speakJob = null
        try { synth?.stop() } catch (_: Exception) { }
        try { backup?.stop() } catch (_: Exception) { }
    }

    fun shutdown() {
        if (destroyed) return
        stop()
        destroyed = true
        downloadJob?.cancel()
        scope.cancel()
        try { synth?.close() } catch (_: Exception) { }
        synth = null
        backup?.shutdown()
        backup = null
        backupReady = false
        starReady = false
    }
}
