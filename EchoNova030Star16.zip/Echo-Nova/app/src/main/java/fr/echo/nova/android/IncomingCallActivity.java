package fr.echo.nova.android;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Locked-screen friendly user decision. The microphone stays off until acceptance. */
public final class IncomingCallActivity extends Activity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setShowWhenLocked(true);
        setTurnScreenOn(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.rgb(10, 19, 32));
        root.setPadding(48, 40, 48, 40);
        TextView title = new TextView(this);
        title.setText("ÉCHO NOVA");
        title.setTextSize(34);
        title.setTextColor(Color.rgb(170, 229, 212));
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView subtitle = new TextView(this);
        subtitle.setText("Elle aimerait discuter.\nAccepter cet appel vocal local ?");
        subtitle.setTextSize(19);
        subtitle.setTextColor(Color.WHITE);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 35, 0, 55);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, -2));
        Button answer = new Button(this);
        answer.setText("Répondre");
        answer.setOnClickListener(v -> {
            IncomingCalls.dismiss(this);
            Intent i = new Intent(this, MainActivity.class).setAction(IncomingCalls.ACTION_ACCEPT)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(i);
            finish();
        });
        root.addView(answer, new LinearLayout.LayoutParams(-1, -2));
        Button decline = new Button(this);
        decline.setText("Refuser");
        decline.setOnClickListener(v -> { IncomingCalls.declined(this); finish(); });
        root.addView(decline, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }
}
