package fr.echo.nova.core;

public final class PrivacyPolicy {
    private PrivacyPolicy() {}
    public static final boolean NEEDS_INTERNET_PERMISSION = false;
    public static final boolean ALLOWS_CLOUD_TRANSCRIPTION = false;
    public static final int MAX_MEMORY_CHARACTERS = 600;
}
