#!/usr/bin/env python3
"""Offline structural checks only. Not a substitute for Android compilation."""
import pathlib
import subprocess
import tempfile
import xml.etree.ElementTree as ET

root = pathlib.Path(__file__).resolve().parents[1]
manifest = root / 'app/src/main/AndroidManifest.xml'
xml = ET.parse(manifest)
android_ns = '{http://schemas.android.com/apk/res/android}'
permissions = [e.attrib[android_ns + 'name'] for e in xml.findall('uses-permission')]
assert set(permissions) == {'android.permission.RECORD_AUDIO', 'android.permission.POST_NOTIFICATIONS', 'android.permission.RECEIVE_BOOT_COMPLETED', 'android.permission.USE_FULL_SCREEN_INTENT'}, permissions
assert not any('INTERNET' in p for p in permissions)
assert (root / 'app/build.gradle.kts').read_text().count('applicationId = "fr.echo.nova.star16"') == 1
assert 'fr.echo.app' not in (root / 'app/build.gradle.kts').read_text()
assert (root / 'app/src/main/java/fr/echo/nova/android/SpeechInput.java').read_text().count('createOnDeviceSpeechRecognizer') == 1
voice = (root / 'app/src/main/java/fr/echo/nova/android/FrenchVoice.kt').read_text()
assert 'star16' in voice and 'Locale.FRANCE' in voice
assert 'setVoiceFallbackEnabled(false)' in voice
assert 'DownloadStatus.DownloadCompleted' in voice
assert 'SpeechSynthesizerResponse.AudioAvailable' in voice
assert 'isNetworkConnectionRequired' in voice
assert 'com.google.mlkit:genai-text-to-speech:1.0.0-alpha1' in (root / 'app/build.gradle.kts').read_text()
assert 'android:allowBackup="false"' in manifest.read_text()
assert xml.find('application/activity/intent-filter') is not None
for f in (root / 'app/src/main/res/values').glob('*.xml'):
    ET.parse(f)
ET.parse(root / 'app/src/main/res/drawable/ic_echo_nova.xml')
java_files = [str(p) for p in (root / 'app/src/main/java').rglob('*.java')]
with tempfile.TemporaryDirectory() as tmp:
    subprocess.run(['javac', '--release', '17', '-d', tmp, str(root / 'scripts/SyntaxCheck.java')], check=True)
    subprocess.run(['java', '-cp', tmp, 'SyntaxCheck', *java_files], check=True)
print('OK: manifest, permissions, app ID, ressources XML et séparation des moteurs vérifiés.')
