#!/bin/sh
set -eu
: "${ECHO_NOVA_KEYSTORE:?Chemin du fichier de clé privée nécessaire}"
: "${ECHO_NOVA_STORE_PASSWORD:?Mot de passe du keystore nécessaire}"
: "${ECHO_NOVA_KEY_ALIAS:?Alias de clé nécessaire}"
: "${ECHO_NOVA_KEY_PASSWORD:?Mot de passe de la clé nécessaire}"
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
./scripts/test_core.sh
./gradlew --no-daemon clean :app:assembleRelease
printf '\nAPK Écho Nova signé : %s\n' "$ROOT/app/build/outputs/apk/release/app-release.apk"
