import com.sun.source.util.JavacTask;
import javax.tools.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.io.File;

/** Parse all Java ASTs without Android SDK; does not validate Android APIs. */
public class SyntaxCheck {
    public static void main(String[] args) throws Exception {
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
        try (StandardJavaFileManager manager = compiler.getStandardFileManager(diagnostics, Locale.ROOT, StandardCharsets.UTF_8)) {
            List<File> files = new ArrayList<>();
            for (String path : args) files.add(new File(path));
            Iterable<? extends JavaFileObject> units = manager.getJavaFileObjectsFromFiles(files);
            JavacTask task = (JavacTask) compiler.getTask(null, manager, diagnostics,
                    List.of("--release", "17", "-proc:none"), null, units);
            task.parse();
            long errors = diagnostics.getDiagnostics().stream()
                    .filter(d -> d.getKind() == Diagnostic.Kind.ERROR)
                    .peek(System.err::println).count();
            if (errors > 0) throw new AssertionError(errors + " Java syntax errors");
            System.out.println("OK: " + files.size() + " sources Java analysées syntaxiquement.");
        }
    }
}
