#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
./scripts/test_core.sh
./gradlew --no-daemon clean :app:assembleDebug
printf '\nAPK debug : %s\n' "$ROOT/app/build/outputs/apk/debug/app-debug.apk"
printf 'IMPORTANT : pour la signature privée permanente, utiliser assembleRelease avec ECHO_NOVA_* et conserver le keystore.\n'
