#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
OUT=$(mktemp -d)
trap 'rm -rf "$OUT"' EXIT
javac -encoding UTF-8 --release 17 -d "$OUT" \
    "$ROOT"/app/src/main/java/fr/echo/nova/core/*.java \
    "$ROOT"/tests/fr/echo/nova/core/CoreTest.java
java -ea -cp "$OUT" fr.echo.nova.core.CoreTest
