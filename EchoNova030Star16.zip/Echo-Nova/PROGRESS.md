# Écho Nova 0.3.0 (Star16)

- Code Kotlin ML Kit GenAI TTS pour star16 fr-FR ajouté.
- Boutons installation et test ajoutés à la même UI, appels précédents préservés.
- Aucune modification du projet Écho 4.0.0.
- Prochain jalon: vérifier Gradle et Google SDK puis latence sur Pixel 8.
- Voice-only: modèle dialogue à règles inchangé, interface provisoire.
