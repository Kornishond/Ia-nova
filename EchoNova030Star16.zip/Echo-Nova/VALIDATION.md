# Écho Nova 0.3.0 — Validation

- 45 assertions Java du cœur : à exécuter via `./scripts/test_core.sh`.
- Contrôles structurels : `python3 scripts/verify_project.py`.
- Gradle : `./gradlew --no-daemon clean :app:assembleDebug` — **à confirmer sur GitHub Actions**, SDK Android non disponible dans le conteneur local.
- Test complet sur Pixel 8 : **non effectué**.
- Scénarios requis : statut Star16 disponible / téléchargeable / indisponible ; téléchargement ; première phrase ; arrêt en cours de phrase ; appel accepté ; interruption et réarmement du micro ; mesure latence audio ; fonctionnement hors connexion après installation.
- Vérifier que la voix annoncée est bien Star16 et que Google ne la remplace pas silencieusement (setVoiceFallbackEnabled(false)).
- Vérifier l'installation en parallèle de la version bêta 0.2.0 (identifiants de paquet distincts).
