# Écho Nova 0.3.0 — Star 16, français génératif (préversion)

**Objectif :** utiliser la voix générative `star16` (`fr-FR`) de ML Kit Text-to-Speech sur Pixel 8, sans perdre le prototype d'appels de la 0.2.0.

## Ce qui a changé

- Ajout de **ML Kit GenAI Text-to-Speech `1.0.0-alpha1`** et moteur Kotlin pilotant les événements `Flow`.
- Recherche **exacte** de la voix `star16` parmi celles de `Locale.FRANCE` ; fallback interne ML Kit désactivé afin de ne jamais lui substituer une autre voix en prétendant que c'est Star 16.
- Bouton **Installer Star 16** : vérifie et télécharge le modèle Google seulement après action explicite ; peut nécessiter Internet la première fois et une mise à jour de l'application Google **Reconnaissance et synthèse vocales**.
- Bouton **Tester Star 16** : phrase française de référence, sans dépendance au moteur conversationnel.
- Mesure du **délai avant le premier fragment audio**, affichée dans les diagnostics ; ce n'est pas la latence complète de l'appel.
- Cycle de vie : arrêt de la synthèse lorsqu'on raccroche, annulation des coroutines et fermeture du client à la destruction de l'activité.
- Voix française hors ligne Android conservée comme **secours clairement annoncé**, pas comme équivalent de Star 16.
- Identifiant `fr.echo.nova.star16` distinct des versions précédentes pour ne pas bloquer l'installation lorsque GitHub Actions utilise une clé debug différente, et préserver Écho Nova 0.2 ainsi qu'Écho Work.

## Important

- **Bêta API Google** : la disponibilité de Star 16 dépend des versions du service `com.google.android.tts`, du pays, de l'appareil et de l'état du modèle. Une compatibilité documentée ne remplace pas un test sur le Pixel 8.
- **Toujours pas de véritable modèle conversationnel** : les réponses restent programmées. L'intelligence sera un chantier distinct.
- Les notifications d'appels restent simulées par l'application, pas de vrais appels téléphoniques sur le réseau.
- **Pas encore compilé ni testé sur appareil par nous** : cette archive contient le projet Android, pas un APK.

## Installation via GitHub Actions

1. Télécharger `EchoNova030Star16.zip`, puis l'ajouter en **racine** du dépôt `Kornishond/Ia-nova`.
2. Dans `.github/workflows/build.yml`, remplacer le contenu par le fichier `Echo-Nova-0.3.0-Star16-GitHub.yml` joint séparément.
3. Après compilation réussie, récupérer `Echo-Nova-0.3.0-Star16-APK` dans les artefacts de GitHub Actions.
4. Installer l'APK sur le Pixel 8. Il apparait comme **Écho Nova Star 16**, à côté de la 0.2.0.
5. Mettre à jour **Reconnaissance et synthèse vocales** sur Google Play, ouvrir Écho Star 16, sélectionner **Installer Star 16**, puis **Tester Star 16**. Le téléchargement initial peut demander Internet ; la lecture ensuite est locale.

Sources :
- https://developers.google.com/ml-kit/genai/text-to-speech/android
- https://developers.google.com/android/reference/kotlin/com/google/mlkit/genai/texttospeech/SpeechSynthesizer
