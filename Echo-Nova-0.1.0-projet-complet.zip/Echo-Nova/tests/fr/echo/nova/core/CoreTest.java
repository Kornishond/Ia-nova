package fr.echo.nova.core;

import java.util.ArrayList;
import java.util.List;

public final class CoreTest {
    private static int assertions = 0;
    private static void check(boolean ok, String message) {
        assertions++;
        if (!ok) throw new AssertionError("Test " + assertions + " : " + message);
    }
    static class InMemoryMemory implements MemoryStore {
        List<String> facts = new ArrayList<>();
        public void remember(String fact) { facts.add(fact); }
        public List<String> recallRecent(int limit) { return facts.subList(Math.max(0, facts.size() - limit), facts.size()); }
        public void forgetAll() { facts.clear(); }
    }
    public static void main(String[] args) {
        InMemoryMemory memory = new InMemoryMemory();
        DialogueEngine brain = new DialogueEngine(memory);
        check(brain.reply("").contains("rien reçu"), "blank question");
        check(brain.reply(null).contains("rien reçu"), "null question");
        check(brain.reply("Bonjour").length() > 0, "greeting");
        check(brain.reply("Comment tu t'appelles ?").contains("Écho Nova"), "name");
        check(brain.reply("Tu m'entends ?").contains("arrivé"), "ASR confirmation");
        check(brain.reply("Souviens-toi que j'aime les échecs").contains("mémoire"), "explicit memory");
        check(memory.facts.size() == 1, "memory stored only once");
        check(memory.facts.get(0).equals("j'aime les échecs"), "memory exact text");
        check(brain.reply("De quoi te souviens-tu ?").contains("échecs"), "recall");
        check(brain.reply("Rappelle toi que mon chat s'appelle Nino").contains("mémoire"), "no punctuation memory");
        check(memory.facts.get(1).contains("Nino"), "memory phrase extraction");
        check(brain.reply("Mémorise que je joue de la flûte").contains("mémoire"), "accent phrase memory");
        check(brain.reply("Que sais-tu de moi ?").contains("flûte"), "memory recall accent");
        check(brain.reply("Souviens-toi que").contains("exactement"), "empty memory reject");
        check(memory.facts.size() == 3, "no empty memory stored");
        check(brain.reply("Oublie tout").contains("confirmation"), "no accidental deletion");
        check(memory.facts.size() == 3, "no deletion without UI confirmation");
        check(brain.reply("C'est quoi l'inflation ?").contains("prix"), "inflation");
        check(brain.reply("Qu'est-ce que le PIB ?").contains("territoire"), "GDP");
        check(brain.reply("Tu es une IA ?").contains("règles locales"), "truthful capability");
        check(brain.reply("As-tu Internet ?").contains("sans permission Internet"), "offline");
        check(brain.reply("Quelle heure est-il ?").contains("h"), "local clock");
        check(brain.reply("Quelle date ?").contains("/"), "local date");
        check(brain.reply("Peux-tu résoudre une conjecture inconnue ?").contains("ne sais pas"), "don't invent");
        check(brain.reply("Bonjour").length() > 1, "repeated turn");
        check(brain.reply("Aide-moi").contains("reconnaissance vocale"), "help");
        String large = "x".repeat(601);
        check(brain.reply("Retiens que " + large).contains("trop long"), "memory limit");
        check(memory.facts.size() == 3, "memory rejected large");
        CallState call = new CallState();
        check(!call.isInCall(), "call initially idle");
        call.onListening(); check(call.phase() == CallState.Phase.IDLE, "ignore outside-call states");
        call.startCall(); check(call.isInCall(), "start call");
        call.onListening(); check(call.phase() == CallState.Phase.LISTENING, "listening phase");
        call.onThinking(); check(call.phase() == CallState.Phase.THINKING, "thinking phase");
        call.onSpeaking(); check(call.phase() == CallState.Phase.SPEAKING, "speaking phase");
        call.onTurnFinished(); check(call.phase() == CallState.Phase.IDLE, "next turn");
        call.endCall(); check(!call.isInCall() && call.phase() == CallState.Phase.IDLE, "hang up");
        check(!PrivacyPolicy.NEEDS_INTERNET_PERMISSION && !PrivacyPolicy.ALLOWS_CLOUD_TRANSCRIPTION, "offline privacy");
        check(PrivacyPolicy.MAX_MEMORY_CHARACTERS == 600, "memory limit constant");
        memory.forgetAll(); check(memory.facts.isEmpty(), "clear confirmed");
        System.out.println("OK: " + assertions + " assertions Java purs réussies.");
    }
}
