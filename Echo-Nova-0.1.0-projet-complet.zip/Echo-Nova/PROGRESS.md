# Écho Nova — état réel au 12 novembre 2026

## Terminée dans le code source
- [x] Nouveau projet Android Java distinct, `fr.echo.nova`, version `0.1.0`.
- [x] Permission Internet absente, permissions minimales.
- [x] UI conversation écrite + historique SQLite privé.
- [x] Souvenirs demandés explicitement + rappel + effacement avec confirmation.
- [x] Détection du moteur Android de reconnaissance **sur appareil**, transcriptions partielles, délais de repli.
- [x] Sélection de voix française **sans connexion réseau** uniquement.
- [x] Mode appel à l'écran : état écoute/réponse/voix, sans service de fond.
- [x] Diagnostics, scripts de compilation, Gradle wrapper, pipeline CI optionnel.
- [x] Tests pur Java : 39 assertions exécutées et réussies.
- [x] Création d'une clé release privée **différente** (archive à part).

## Non validé
- [ ] Compilation complète de l'APK Android (`sdkmanager`, `gradle`, SDK Android absents dans cette session).
- [ ] Installation et fonctionnement sur Google Pixel 8.
- [ ] Reconnaissance française on-device disponible + transcription fiable.
- [ ] Voix locale française disponible et naturelle.
- [ ] Conversation orale pendant 20-30 min sans plantage.
- [ ] Signature de l'APK release et test de mise à jour avec la même clé.
- [ ] Intégration d'un véritable modèle de langage quantifié et de sa gestion mémoire.
- [ ] Appels autonomes futurs, personnalité et mémoire relationnelle avancées.

## Prochaines actions pour une session équipée d'Android SDK
1. `./scripts/test_core.sh`.
2. `./gradlew :app:assembleDebug` puis résoudre d'éventuelles erreurs d'API Android.
3. Compiler en release avec la clé dédiée fournie séparément.
4. Installer sur Pixel 8 à côté d'Écho Work (vérifier deux icônes / deux IDs).
5. Tester les six étapes du README sur matériel réel.
6. Sélectionner et intégrer un modèle de langage réellement local, après mesures des ressources.
