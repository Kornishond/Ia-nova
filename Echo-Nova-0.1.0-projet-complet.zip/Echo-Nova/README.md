# Écho Nova 0.1.0 — nouveau projet indépendant

**Écho Nova est un nouveau projet Android créé de zéro.** Il ne reprend aucun
fichier Kotlin ou composant métier des versions Écho 0.3.x et 4.0.0.
Seuls les fichiers standards du wrapper Gradle (outil de construction) ont été
réutilisés. Identifiant Android : **`fr.echo.nova`**, différent de
`fr.echo.app` utilisé par l'autre application Écho.

## Ce qui a été réellement implémenté

- Interface Android sombre, conversation écrite, historique local persistant SQLite.
- Mémorisation **explicite** avec « Souviens-toi que… », et rappel « De quoi te souviens-tu ? ».
- Moteur conversationnel initial **déterministe à règles**, sans serveur, sans mensonge sur ses capacités.
- Reconnaissance par `SpeechRecognizer.createOnDeviceSpeechRecognizer` (Android 12+, voix en français). Transcriptions partielles affichées et récupérées si le résultat final tarde.
- Synthèse vocale avec `TextToSpeech` **exclusivement pour une voix locale en français**. Si aucune voix française locale n'est installée, texte uniquement : pas de repli dans une mauvaise langue.
- Mode « Appeler » qui alterne écoute, réponse puis voix dans **l'activité au premier plan**. Ce n'est pas un appel téléphonique réel, ni une activité permanente en arrière-plan.
- Permission du micro demandée à l'usage ; destruction des moteurs lorsqu'ils ne sont plus nécessaires ; aucun accès réseau via permission INTERNET.
- Diagnostics, confirmation avant effacement, aucune migration ni suppression des données d'Écho Work.
- 39 assertions de tests Java autonomes, et un workflow GitHub Actions optionnel pour construire un APK debug.

## Ce qui N'EST PAS encore implémenté

- **Aucun véritable LLM embarqué** : les réponses libres sont limitées. Un modèle quantifié, son moteur d'inférence et des tests RAM Pixel 8 devront être intégrés ultérieurement.
- Pas de Pocket TTS, ML Kit GenAI TTS, ni de voix humaine garantie.
- Pas d'appels autonomes spontanés, d'appels système, de contrôle arrière-plan, ni de mémoire relationnelle avancée.
- Pas de preuve que le moteur français Android soit installé ou performant sur ton Pixel 8.
- **Aucun APK Android compilé dans l'environnement actuel** (SDK Android, Gradle non disponibles hors ligne). Le code Java non Android a été compilé et testé séparément.

## Construire sur un PC avec Android Studio

1. Installer Android Studio avec le SDK Android 35 et le JDK 17 ou supérieur.
2. Ouvrir le dossier `Echo-Nova` comme projet Android dans Android Studio.
3. Laisser Gradle 8.13 et Android Gradle Plugin 8.9.2 se télécharger la première fois.
4. Lancer `./scripts/test_core.sh` (Linux/macOS) ou exécuter les tests avec `javac`/`java` sous Windows.
5. Lancer `./gradlew assembleDebug` ou **Build > Build APK(s)** dans Android Studio.
6. Récupérer `app/build/outputs/apk/debug/app-debug.apk`, installer sur le Pixel 8 et accorder l'accès au micro.
7. Pour des mises à jour **toujours signées par la même clé**, utiliser le keystore Écho Nova **fourni séparément**, avec `./scripts/build_release.sh` et ses quatre variables `ECHO_NOVA_*`.

### Compiler sans PC, si tu possèdes un compte GitHub

1. Créer un dépôt privé à partir du contenu de ce ZIP (ne jamais y mettre le ZIP de clé privée).
2. Ouvrir **Actions → Compile Echo Nova APK (debug) → Run workflow**.
3. Une fois la compilation réussie, récupérer l'artefact **Echo-Nova-debug-APK**.
4. **Attention :** les builds debug peuvent changer de clé selon l'environnement CI ; pour des mises à jour reproductibles, utiliser une signature release conservée en sécurité.

Il s'agit d'une procédure facultative de compilation distante : l'application installée fonctionne **sans Internet**. Les compilations en ligne doivent être utilisées seulement si tu le souhaites.

## Diagnostic sur Pixel 8 (test réel requis)

1. Écrire `Bonjour`, appuyer sur Envoyer et vérifier une réponse écrite.
2. Dire `Souviens-toi que j'aime les échecs`, redémarrer l'application, puis demander `De quoi te souviens-tu ?`.
3. Accorder l'autorisation microphone, toucher « Micro », parler ; vérifier l'affichage de la transcription provisoire puis finale.
4. Installer une **voix française locale** dans la synthèse vocale Android si nécessaire. Vérifier qu'Écho lit sa réponse à haute voix.
5. Avec voix et reconnaissance disponibles, toucher « Appeler » et enchaîner cinq questions, puis raccrocher.
6. Couper Wi-Fi et données mobiles, refaire les tests. Vérifier qu'aucune permission INTERNET n'est déclarée.

Si la reconnaissance locale française n'est pas disponible, **la conversation écrite reste utilisable**, mais pas le mode « Appeler ». Le moteur d'Android peut nécessiter le téléchargement initial du modèle français dans les paramètres du Pixel.

## Sécurité de la clé

Le **ZIP de signature privée est distinct du code source**. Il contient le keystore
privé et ses informations d'accès. Le conserver hors des dépôts et des
conversations partagées ; sa perte empêche de publier une mise à jour sous la
même signature. Le certificat Écho Nova est créé indépendamment de celui de Work.
Ne pas changer l'application ID en `fr.echo.app` : la séparation protège les
installations existantes, et une signature différente empêcherait de les remplacer.

## Organisation

- `app/src/main/java/fr/echo/nova/core` : moteur et règles testables sans Android.
- `app/src/main/java/fr/echo/nova/android` : stockage, reconnaissance, voix, interface.
- `tests` et `scripts/test_core.sh` : tests autonomes avec Java 17.
- `scripts/build_android.sh` : compilation APK debug.
- `scripts/build_release.sh` : compilation signée avec la clé Écho Nova.
- `.github/workflows/build-apk.yml` : construction optionnelle sur GitHub.

Cette base peut être améliorée sans affecter Écho 4.0.0 de Work.
